﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponState : MonoBehaviour {

	public bool isMelee = false;
	public int meleeIndex = 0;
	public int weaponIndex = 0;
	public int bulletsLeft = 30;
	public int ammoLeft = 5;


}
