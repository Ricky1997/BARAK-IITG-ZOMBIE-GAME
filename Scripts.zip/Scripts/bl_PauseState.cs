﻿using UnityEngine;

public enum PauseState
{
    Main,
    Options,
    Credits,
    None,
}
