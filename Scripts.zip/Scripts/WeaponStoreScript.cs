﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class WeaponStoreScript : MonoBehaviour {

	public WeaponInventory wI;
	public PlayerVitals pS;

	public void buyM4(){
		//if()
	}

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
