﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI ;

public class PlayerVitals : MonoBehaviour
{
    //public Spawn spawn;
	public Movement playerMovement;
    public GameObject obj;
    public float hitPoints = 100;
    public Rigidbody wep;
    public Transform hitCam;
    public Transform hitWep;
	//public int startingHealth = 100;                            // The amount of health the player starts the game with.
	//public int currentHealth;                                   // The current health the player has.
	public Slider healthSlider;                                 // Reference to the UI's health bar.
	public Image damageImage;                                   // Reference to an image to flash on the screen on being hurt.
	public AudioClip deathClip;                                 // The audio clip to play when the player dies.
	public float flashSpeed = 2f;                               // The speed the damageImage will fade at.
	public Color flashColour = new Color(1f, 1f, 1f, 1f);     // The colour the damageImage is set to, to flash.

	public Text killText;
	public int kills = 0;
	public int score = 0;

	public Animator anim;                                              // Reference to the Animator component.
	AudioSource playerAudio;                                    // Reference to the AudioSource component.
	//Movement playerMovement;                              // Reference to the player's movement.
	//PlayerShooting playerShooting;                              // Reference to the PlayerShooting script.
	bool isDead=false;                                                // Whether the player is dead.
	bool damaged;                                               // True when the player gets damaged.


	void Awake ()
	{
		//anim = GetComponent <Animator> ();
		//playerAudio = GetComponent <AudioSource> ();

		//playerShooting = GetComponentInChildren <PlayerShooting> ();

		healthSlider.value =hitPoints;
	}

    void Start()
    {
		Cursor.lockState = CursorLockMode.Locked;
        //spawn = GameObject.FindWithTag("GameController").GetComponent<Spawn>();
        Rigidbody[] bodies = obj.GetComponentsInChildren<Rigidbody>();
        Collider[] collies = obj.GetComponentsInChildren<Collider>();
        wep.useGravity = false;
        wep.isKinematic = true;
		//playerMovement = GetComponent <Movement> ();
        wep.GetComponent<Collider>().isTrigger = true;
        foreach (Rigidbody body in bodies)
        {
            body.useGravity = false;
            body.isKinematic = true;
        }
        foreach (Collider coll in collies)
        {
            coll.isTrigger = true;
        }
    }

    void Update()
	{	// If the player has just been damaged...

		//if (isLocalPlayer) {
			if (damaged) {
				// ... set the colour of the damageImage to the flash colour.
				damageImage.color = flashColour;
			}
		// Otherwise...
		else {
				// ... transition the colour back to clear.
				damageImage.color = Color.Lerp (damageImage.color, Color.clear, flashSpeed * Time.deltaTime);
			}

			// Reset the damaged flag.
			damaged = false;
			killText.text = kills.ToString ();
			hitPoints = Mathf.Clamp (hitPoints, 0, 100);
			hitCam.localRotation = Quaternion.Lerp (hitCam.localRotation, Quaternion.identity, Time.deltaTime * 5);
			hitWep.localRotation = Quaternion.Lerp (hitWep.localRotation, Quaternion.identity, Time.deltaTime * 5);
		//}
    }

    //[RPC]
    public void ApplyDamage(float dmg, int isBullet)
    {
        hitPoints -= dmg;
        StartCoroutine(Kick3(hitWep, new Vector3(-3f * dmg / 10, Random.Range(-3, 3) * dmg / 10, 0), 0.1f));
        StartCoroutine(Kick3(hitCam, new Vector3(-5f * dmg / 10, Random.Range(-5, 5) * dmg / 10, 0), 0.1f));
		// Set the health bar's value to the current health.
		healthSlider.value = hitPoints;
		//anim.SetTrigger ("DamageTaken");
		// Play the hurt sound effect.
		//playerAudio.Play ();
		damaged = true;
		// If the player has lost all it's health and the death flag hasn't been set yet...
		if(hitPoints <= 0 && !isDead)
		{
			// ... it should die.
			Die ();
		}
        //if (hitPoints <= 0)
        //{
            //GetComponent<NetworkView>().RPC("Die", RPCMode.AllBuffered);
        //}
		//anim.SetTrigger ("NoDamage");
    }
	public void Medic(float heal)
	{
		hitPoints += heal;
		// Set the health bar's value to the current health.
		hitPoints = Mathf.Clamp(hitPoints, 0, 100);
		healthSlider.value = hitPoints;

	}

    IEnumerator Kick3(Transform goTransform, Vector3 kbDirection, float time)
    {
        Quaternion startRotation = goTransform.localRotation;
        Quaternion endRotation = goTransform.localRotation * Quaternion.Euler(kbDirection);
        float rate = 1.0f / time;
        var t = 0.0f;
        while (t < 1.0f)
        {
            t += Time.deltaTime * rate;
            goTransform.localRotation = Quaternion.Slerp(startRotation, endRotation, t);
            yield return null;
        }
    }

   // [RPC]
    protected void Die()
    {

		isDead = true;

		// Turn off any remaining shooting effects.
		//playerShooting.DisableEffects ();

		// Tell the animator that the player is dead.
		anim.SetTrigger ("PlayerDead");

		// Set the audiosource to play the death clip and play it (this will stop the hurt sound from playing).
		//playerAudio.clip = deathClip;
		//playerAudio.Play ();

		// Turn off the movement and shooting scripts.
		playerMovement.enabled = false;



        //Destroy(obj.GetComponent<PlayerAnimations>());
        //Destroy(obj.GetComponent<Animator>());
        //Rigidbody[] bodies = obj.GetComponentsInChildren<Rigidbody>();
       // Collider[] collies = obj.GetComponentsInChildren<Collider>();
        /*foreach (Rigidbody body in bodies)
        {
            body.useGravity = true;
            body.isKinematic = false;
        }
        foreach (Collider coll in collies)
        {
            coll.isTrigger = false;
        }*/
        wep.useGravity = true;
        wep.isKinematic = false;
        //wep.GetComponent<Collider>().isTrigger = false;
        //wep.transform.parent = null;
		/*
        if (GetComponent<NetworkView>().isMine)
        {
            spawn.Die();
        }*/
        //obj.transform.parent = null;
        //Destroy(wep, 10);
        //Destroy(obj, 10);
        //Destroy(this.gameObject);
    }

}
