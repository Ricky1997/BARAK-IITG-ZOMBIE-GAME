﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityStandardAssets.ImageEffects;

public class LevelManager : MonoBehaviour {

	public int gameLevel = 1;
	public bool levelCompleted = false;
	public bool levelSpawnComplete = false;
	public bool levelActive = false;
	int Difficulty = 1;
	public SpawnManager spawnM;
	public FogScript fogParticle;
	public GlobalFog fogOfWar;
	// Use this for initialization
	void Start () {
		gameLevel = 1;
		StartLevel (gameLevel);
		//spawnM = gameObject.GetComponent<SpawnManager> ();
	}
	
	// Update is called once per frame
	void Update () {
		//if (isLocalPlayer) {
			if (levelActive) {
		
				if (levelSpawnComplete && ZombieHealth.zombieAlive == 0) {
					levelCompleted = true;

				}
				
		
			}
			if (levelCompleted) {
				gameLevel++;
				StartLevel (gameLevel * 5);
		
		
			}
		//}
	}

	public void StartLevel(int level){
		//Debug.Break ();
		levelActive = true;
		levelCompleted = false;
		levelSpawnComplete = false;
		Debug.Log ("LevelStarted");
		spawnM.SetLevel (level);
		//spawnM.SpawnZombies ();
		StartCoroutine (spawnM.SpawnZombies ());





	}
}
